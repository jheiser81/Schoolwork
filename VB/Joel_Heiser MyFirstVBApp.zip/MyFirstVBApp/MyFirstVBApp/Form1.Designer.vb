﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Button1 = New Button()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        TextBox4 = New TextBox()
        TextBox5 = New TextBox()
        TextBox6 = New TextBox()
        Button2 = New Button()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        TextBox7 = New TextBox()
        TextBox8 = New TextBox()
        TextBox9 = New TextBox()
        TextBox10 = New TextBox()
        TextBox11 = New TextBox()
        TextBox12 = New TextBox()
        Button3 = New Button()
        Button4 = New Button()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        Label14 = New Label()
        Label15 = New Label()
        TextBox13 = New TextBox()
        TextBox14 = New TextBox()
        TextBox15 = New TextBox()
        Button5 = New Button()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(12, 156)
        Button1.Name = "Button1"
        Button1.Size = New Size(131, 40)
        Button1.TabIndex = 0
        Button1.Text = "sum"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(12, 47)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(175, 35)
        TextBox1.TabIndex = 1
        TextBox1.Text = "20"' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(12, 98)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(175, 35)
        TextBox2.TabIndex = 2
        TextBox2.Text = "5"' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(12, 213)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(175, 35)
        TextBox3.TabIndex = 3
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(229, 52)
        Label1.Name = "Label1"
        Label1.Size = New Size(66, 30)
        Label1.TabIndex = 4
        Label1.Text = "num1"' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(229, 98)
        Label2.Name = "Label2"
        Label2.Size = New Size(66, 30)
        Label2.TabIndex = 5
        Label2.Text = "num2"' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(233, 213)
        Label3.Name = "Label3"
        Label3.Size = New Size(52, 30)
        Label3.TabIndex = 6
        Label3.Text = "sum"' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(12, 290)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(175, 35)
        TextBox4.TabIndex = 7
        TextBox4.Text = "20"' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(12, 345)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(175, 35)
        TextBox5.TabIndex = 8
        TextBox5.Text = "5"' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(12, 465)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(175, 35)
        TextBox6.TabIndex = 9
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(12, 398)
        Button2.Name = "Button2"
        Button2.Size = New Size(131, 40)
        Button2.TabIndex = 10
        Button2.Text = "difference"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(233, 297)
        Label4.Name = "Label4"
        Label4.Size = New Size(66, 30)
        Label4.TabIndex = 11
        Label4.Text = "num3"' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(233, 350)
        Label5.Name = "Label5"
        Label5.Size = New Size(66, 30)
        Label5.TabIndex = 12
        Label5.Text = "num4"' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(229, 468)
        Label6.Name = "Label6"
        Label6.Size = New Size(106, 30)
        Label6.TabIndex = 13
        Label6.Text = "difference"' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(353, 47)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(175, 35)
        TextBox7.TabIndex = 14
        TextBox7.Text = "20"' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(353, 98)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(175, 35)
        TextBox8.TabIndex = 15
        TextBox8.Text = "5"' 
        ' TextBox9
        ' 
        TextBox9.Location = New Point(353, 208)
        TextBox9.Name = "TextBox9"
        TextBox9.Size = New Size(175, 35)
        TextBox9.TabIndex = 16
        ' 
        ' TextBox10
        ' 
        TextBox10.Location = New Point(353, 297)
        TextBox10.Name = "TextBox10"
        TextBox10.Size = New Size(175, 35)
        TextBox10.TabIndex = 17
        TextBox10.Text = "20"' 
        ' TextBox11
        ' 
        TextBox11.Location = New Point(353, 350)
        TextBox11.Name = "TextBox11"
        TextBox11.Size = New Size(175, 35)
        TextBox11.TabIndex = 18
        TextBox11.Text = "5"' 
        ' TextBox12
        ' 
        TextBox12.Location = New Point(353, 468)
        TextBox12.Name = "TextBox12"
        TextBox12.Size = New Size(175, 35)
        TextBox12.TabIndex = 19
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(353, 156)
        Button3.Name = "Button3"
        Button3.Size = New Size(131, 40)
        Button3.TabIndex = 20
        Button3.Text = "product"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(353, 398)
        Button4.Name = "Button4"
        Button4.Size = New Size(131, 40)
        Button4.TabIndex = 21
        Button4.Text = "quotient"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(584, 47)
        Label7.Name = "Label7"
        Label7.Size = New Size(66, 30)
        Label7.TabIndex = 22
        Label7.Text = "num5"' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(584, 103)
        Label8.Name = "Label8"
        Label8.Size = New Size(66, 30)
        Label8.TabIndex = 23
        Label8.Text = "num6"' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(584, 208)
        Label9.Name = "Label9"
        Label9.Size = New Size(85, 30)
        Label9.TabIndex = 24
        Label9.Text = "product"' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(584, 293)
        Label10.Name = "Label10"
        Label10.Size = New Size(66, 30)
        Label10.TabIndex = 25
        Label10.Text = "num7"' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Location = New Point(584, 345)
        Label11.Name = "Label11"
        Label11.Size = New Size(66, 30)
        Label11.TabIndex = 26
        Label11.Text = "num8"' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Location = New Point(584, 465)
        Label12.Name = "Label12"
        Label12.Size = New Size(91, 30)
        Label12.TabIndex = 27
        Label12.Text = "quotient"' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Location = New Point(941, 52)
        Label13.Name = "Label13"
        Label13.Size = New Size(66, 30)
        Label13.TabIndex = 28
        Label13.Text = "num9"' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Location = New Point(941, 106)
        Label14.Name = "Label14"
        Label14.Size = New Size(77, 30)
        Label14.TabIndex = 29
        Label14.Text = "num10"' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Location = New Point(941, 205)
        Label15.Name = "Label15"
        Label15.Size = New Size(107, 30)
        Label15.TabIndex = 30
        Label15.Text = "remainder"' 
        ' TextBox13
        ' 
        TextBox13.Location = New Point(711, 52)
        TextBox13.Name = "TextBox13"
        TextBox13.Size = New Size(175, 35)
        TextBox13.TabIndex = 31
        TextBox13.Text = "20"' 
        ' TextBox14
        ' 
        TextBox14.Location = New Point(711, 103)
        TextBox14.Name = "TextBox14"
        TextBox14.Size = New Size(175, 35)
        TextBox14.TabIndex = 32
        TextBox14.Text = "5"' 
        ' TextBox15
        ' 
        TextBox15.Location = New Point(711, 205)
        TextBox15.Name = "TextBox15"
        TextBox15.Size = New Size(175, 35)
        TextBox15.TabIndex = 33
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(711, 156)
        Button5.Name = "Button5"
        Button5.Size = New Size(131, 40)
        Button5.TabIndex = 34
        Button5.Text = "Modulus"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(12F, 30F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1521, 684)
        Controls.Add(Button5)
        Controls.Add(TextBox15)
        Controls.Add(TextBox14)
        Controls.Add(TextBox13)
        Controls.Add(Label15)
        Controls.Add(Label14)
        Controls.Add(Label13)
        Controls.Add(Label12)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Button4)
        Controls.Add(Button3)
        Controls.Add(TextBox12)
        Controls.Add(TextBox11)
        Controls.Add(TextBox10)
        Controls.Add(TextBox9)
        Controls.Add(TextBox8)
        Controls.Add(TextBox7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Button2)
        Controls.Add(TextBox6)
        Controls.Add(TextBox5)
        Controls.Add(TextBox4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Controls.Add(Button1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents Button5 As Button
End Class
