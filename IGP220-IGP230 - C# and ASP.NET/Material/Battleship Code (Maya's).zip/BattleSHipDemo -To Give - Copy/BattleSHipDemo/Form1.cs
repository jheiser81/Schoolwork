using Microsoft.VisualBasic;
using System.Collections.Generic;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;

namespace BattleSHipDemo
{
    public partial class Form1 : Form
    {
        PictureBox[,] playerBoard = new PictureBox[10, 10];
        PictureBox[,] computerBoard = new PictureBox[10, 10];
        int HumanShots = 0;
        int CompShots = 0;
        int PlayerHitCount = 0;
        int ComputerHitCount = 0;
        HashSet<int> PlayerLocations = new HashSet<int>();
        HashSet<int> ComputerLocations = new HashSet<int>();
        List<int> CompLoacations = new List<int>();
        Label[] LocationX = new Label[20];
        Label[] LocationY = new Label[10];
        public Form1()
        {
            InitializeComponent();
        }
        //shot count 
        private void Form1_Load(object sender, EventArgs e)
        {
            PrintBoard();
            RandomAssignment();
            DisplayShips();
            TurnAssignemnt();
        }
        void RandomAssignment()
        {
            Random rnd = new Random();//this is an object that allows us to generate random numbers
            while (PlayerLocations.Count < 8)//if player locations is less than 8 then we ca
            {
                int xLocation = rnd.Next(10);
                PlayerLocations.Add(xLocation);//this allows us to define our player location
                int yLocation = rnd.Next(10);
                PlayerLocations.Add(yLocation);//this allows us to define our player location
            }
            while (ComputerLocations.Count < 8)
            {
                int xLocation = rnd.Next(10);
                ComputerLocations.Add(xLocation);
                int yLocation = rnd.Next(10);
                ComputerLocations.Add(yLocation);
            }
            //Use a random number genorator
            //Use a data structure called "HashSet" line 16 and 17 (do research)
            //while the hashset has less then 8 numbers genorate random numbers for playerLocation
            //add a location x and y           
            //while the hashset.Count has less then 8 numbers genorate random numbers for ComputerLocation
            //add a location x and y           
        }
        private void PrintBoard()
        {
            //Use the code you have already written to print the game board           
            int xpos = 100, ypos = 120;
            int xposComp = 850, yposComp = 120;
            for (int row = 0; row <= playerBoard.GetUpperBound(0); row++)
            {
                for (int column = 0; column <= playerBoard.GetUpperBound(1); column++)
                {
                    if (row == 0)
                    {
                        LocationX[column] = new Label
                        {
                            Name = "Label" + row.ToString() + ", " + column.ToString(),
                            Location = new Point(xposComp, yposComp - 60),
                            Size = new Size(60, 60),
                            Visible = true,
                            Text = column.ToString(),
                            Font = new Font("Arial", 20),
                            TextAlign = ContentAlignment.MiddleCenter
                        };
                        this.Controls.Add(LocationX[column]);
                        LocationX[column + 10] = new Label
                        {
                            Name = "Label" + row.ToString() + ", " + column.ToString(),
                            Location = new Point(xpos, ypos - 60),
                            Size = new Size(60, 60),
                            Visible = true,
                            Text = column.ToString(),
                            Font = new Font("Arial", 20),
                            TextAlign = ContentAlignment.MiddleCenter
                        };
                        this.Controls.Add(LocationX[column + 10]);
                    }
                    if (column == 0)
                    {

                        LocationY[row] = new Label
                        {
                            Name = "Label" + row.ToString() + ", " + column.ToString(),
                            Location = new Point(xposComp - 95, yposComp),
                            Size = new Size(60, 60),
                            Visible = true,
                            Text = Convert.ToString((char)((row) + 65)),//converts the index number to a capitol Letter 1=A, 2=B...
                            Font = new Font("Arial", 20),
                            TextAlign = ContentAlignment.MiddleCenter
                        };
                        this.Controls.Add(LocationY[row]);
                    }
                    playerBoard[row, column] = new PictureBox
                    {
                        Name = "picturebox" + row.ToString() + ", " + column.ToString(),
                        Location = new Point(xpos, ypos),
                        Size = new Size(60, 60),
                        Visible = true,
                        ImageLocation = "./waves.png"
                    };
                    this.Controls.Add(playerBoard[row, column]);

                    computerBoard[row, column] = new PictureBox();
                    computerBoard[row, column].Name = "picturebox" + row.ToString() + ", " + column.ToString(); ;
                    computerBoard[row, column].Location = new Point(xposComp, yposComp);
                    computerBoard[row, column].Size = new Size(60, 60);
                    computerBoard[row, column].Visible = true;
                    computerBoard[row, column].ImageLocation = "./waves.png";
                    this.Controls.Add(computerBoard[row, column]);
                    computerBoard[row, column].Click += new EventHandler(Player_Click);
                    xpos = xpos + 60;
                    xposComp = xposComp + 60;
                }
                ypos += 60;
                xpos = 100;
                yposComp += 60;
                xposComp = 850;
            }
        }

        void TurnAssignemnt()
        {
            //use a random number to make a turn for computer or for the player
            //if player goes they get to click
            //if computer goes then call computerTurn()
            Random random = new Random();
            int TurnAss = random.Next();
            if (TurnAss % 2 == 0)
            {
                MessageBox.Show("Players Turn");
            }
            else
            {
                MessageBox.Show("Computers Turn");
                ComputerTurn();
            }
        }
        void DisplayShips()
        {
            //Convert your HashSet.ToList() for the playerLocation, List is another data structure that acts like an array
            //Change the image location from water to ships  
            List<int> MyPlace = PlayerLocations.ToList();
            playerBoard[MyPlace[0], MyPlace[1]].ImageLocation = "./Ship.png";
            playerBoard[MyPlace[2], MyPlace[3]].ImageLocation = "./Ship.png";
            playerBoard[MyPlace[4], MyPlace[5]].ImageLocation = "./Ship.png";
            playerBoard[MyPlace[6], MyPlace[7]].ImageLocation = "./Ship.png";
            //Convert your HashSet.ToList() for the computerLocation, List is another data structure that acts like an array
            //Change the image location from water to ships
            CompLoacations = ComputerLocations.ToList();

            //comment out the ships below to have a real game experiance 
            computerBoard[CompLoacations[0], CompLoacations[1]].ImageLocation = "./Ship.png";
            computerBoard[CompLoacations[2], CompLoacations[3]].ImageLocation = "./Ship.png";
            computerBoard[CompLoacations[4], CompLoacations[5]].ImageLocation = "./Ship.png";
            computerBoard[CompLoacations[6], CompLoacations[7]].ImageLocation = "./Ship.png";
        }
        void Player_Click(object sender, EventArgs e)
        {
            PictureBox ClickedPictureBox = (PictureBox)sender;
            int xAttacked = Convert.ToInt32(ClickedPictureBox.Name.Substring(10, 1));
            int yAttacked = Convert.ToInt32(ClickedPictureBox.Name.Substring(12));
            if (CompLoacations[0] == xAttacked && CompLoacations[1] == yAttacked || CompLoacations[2] == xAttacked && CompLoacations[3] == yAttacked || CompLoacations[4] == xAttacked && CompLoacations[5] == yAttacked || CompLoacations[6] == xAttacked && CompLoacations[7] == yAttacked)
            {
                computerBoard[xAttacked, yAttacked].ImageLocation = "images.jfif";
                PlayerHitCount++;
            }
            else if (computerBoard[xAttacked, yAttacked].ImageLocation == "./waves.png")
            {
                computerBoard[xAttacked, yAttacked].ImageLocation = "miss.jfif";
            }
            else
            {
                MessageBox.Show("You crazy human that has already be pressed please try again...");
                return;
            }
            bool endgame = WinCheck();
            if (endgame == false)
            {
                ComputerTurn();
            }
        }
        void ComputerTurn()
        {
            Random random = new Random();
            int xAttacked = random.Next(10);
            int yAttacked = random.Next(10);
            if (playerBoard[yAttacked, xAttacked].ImageLocation == "./Ship.png")
            {
                MessageBox.Show("Computer attacks " + yAttacked.ToString() + xAttacked.ToString());
                playerBoard[yAttacked, xAttacked].ImageLocation = "images.jfif";
                ComputerHitCount++;
            }
            else if (playerBoard[yAttacked, xAttacked].ImageLocation == "./waves.png")
            {
                MessageBox.Show("Computer Misses" + yAttacked.ToString() + xAttacked.ToString());
                playerBoard[yAttacked, xAttacked].ImageLocation = "miss.jfif";
            }
            else
            {
                ComputerTurn();
            }

            WinCheck();
        }
        bool WinCheck()
        {
            if (PlayerHitCount == 4)
            {
                MessageBox.Show("Player wins!!!");
                Reset();
                return true;
            }
            if (ComputerHitCount == 4)
            {
                MessageBox.Show("Computer wins!!!");
                Reset();
                return true;
            }
            return false;
        }


        void Reset()
        {
            PlayerLocations = new HashSet<int>();
            ComputerLocations = new HashSet<int>();
            RandomAssignment();
            for (int row = 0; row <= playerBoard.GetUpperBound(0); row++)
            {
                for (int column = 0; column <= playerBoard.GetUpperBound(1); column++)
                {
                    playerBoard[row, column].ImageLocation = "./waves.png";
                    computerBoard[row, column].ImageLocation = "./waves.png";
                }
            }
            PlayerHitCount = 0;
            ComputerHitCount = 0;
            DisplayShips();
            TurnAssignemnt();
        }
    }
}