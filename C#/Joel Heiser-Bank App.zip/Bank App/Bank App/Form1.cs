using System.Data.SqlClient;

namespace Bank_App
{
    public partial class Form1 : Form
    {
        private SqlConnection connObj;
        //private string First_Name;
        //private string Last_Name;
        //private string Street_No;
        //private string Street_Name;
        //private string City;
        //private string Province;
        //private string Postal_Code;
        //private string Phone_No;
        //private string Email;
        //private string DOB;
        //private string Customer_ID;

        //old code, moved into NewCustomers form

        public Form1()
        {
            //First_Name = "";
            //Last_Name = "";
            //Street_No = "";
            //Street_Name = "";
            //City = "";
            //Province = "";
            //Postal_Code = "";
            //Phone_No = "";
            //Email = "";
            //DOB = "";
            //Customer_ID = "";

            InitializeComponent();

            find_ID_btn.Click += Button_Click;
            insert_btn.Click += Button_Click;
            update_btn.Click += Button_Click;
            del_btn.Click += Button_Click;
            clear_btn.Click += Button_Click;
            prev_btn.Click += Button_Click;
            next_btn.Click += Button_Click;
            //this references the buttons on the form and calls the Button_Click function when they are clicked
        }

        private void RunSQLCommand(NewCustomer InsertCustomer, string SQLQuery)
        {
            using (SqlCommand command = new SqlCommand(SQLQuery, connObj))
            {
                command.Parameters.AddWithValue("@First_Name", InsertCustomer.First_Name);
                command.Parameters.AddWithValue("@Last_Name", InsertCustomer.Last_Name);
                command.Parameters.AddWithValue("@Street_No", InsertCustomer.Street_No);
                command.Parameters.AddWithValue("@Street_Name", InsertCustomer.Street_Name);
                command.Parameters.AddWithValue("@City", InsertCustomer.City);
                command.Parameters.AddWithValue("@Province", InsertCustomer.Province);
                command.Parameters.AddWithValue("@Postal_Code", InsertCustomer.Postal_Code);
                command.Parameters.AddWithValue("@Phone_No", InsertCustomer.Phone_No);
                command.Parameters.AddWithValue("@Email", InsertCustomer.Email);
                command.Parameters.AddWithValue("@DOB", InsertCustomer.DOB);
                command.Parameters.AddWithValue("@Customer_ID", InsertCustomer.Customer_ID);
                command.ExecuteNonQuery();
                //moved the SQL command to a function so it can be used for all of the buttons
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            connObj = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='G:\My Drive\Schoolwork\VS Repos\C#\Bank App\Bank App\Bank.mdf';Integrated Security=True");  //path had to be in single quotes from G: onwards
            connObj.Open(); //opens connection to database
        }

        private bool AreTextboxesEmpty()
        {
            if (Fname_box.Text == "" || Lname_box.Text == "" || street_no_box.Text == "" || street_name_box.Text == "" || city_box.Text == "" || prov_box.Text == "" || pc_box.Text == "" || phone_box.Text == "" || email_box.Text == "" || dob_box.Text == "")
            //moved this into a function to make code cleaner
            //checks if any of the fields in the form are empty
            {
                MessageBox.Show("Please fill in all fields");
                return true;
            }
            return false;
        }

        private NewCustomer FillFormVariables()
        {
            NewCustomer customer = new NewCustomer();
            customer.First_Name = Fname_box.Text.ToUpper();
            customer.Last_Name = Lname_box.Text.ToUpper();
            customer.Street_No = street_no_box.Text;
            customer.Street_Name = street_name_box.Text.ToUpper();
            customer.City = city_box.Text.ToUpper();
            customer.Province = prov_box.Text.ToUpper();
            customer.Postal_Code = pc_box.Text.ToUpper();
            customer.Phone_No = phone_box.Text;
            customer.Email = email_box.Text.ToUpper();
            customer.DOB = dob_box.Value;
            customer.Customer_ID = Cust_ID_box.Text;
            return customer;
            //moved into a function, prevents duplicated code
        }

        private void Button_Click(object sender, EventArgs e)
        {
            find_ID_btn.BackColor = SystemColors.Window;
            insert_btn.BackColor = SystemColors.Window;
            update_btn.BackColor = SystemColors.Window;
            del_btn.BackColor = SystemColors.Window;
            clear_btn.BackColor = SystemColors.Window;
            prev_btn.BackColor = SystemColors.Window;
            next_btn.BackColor = SystemColors.Window;
            //this sets the color of the buttons to the default

            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                clickedButton.BackColor = Color.LightBlue;
                //this sets the color of the button that was clicked to light blue
            }
        }

        private void insert_btn_Click(object sender, EventArgs e) //try to make a boolean variable to hold this data instead of repeating code
        {// ------------This is a requierment--------------//
         //You should have a connection to the data base on your form load
         // Using SqlCommand and SqlDataReader do the following

            //make sure all of the textboxes are filled in
            //search if the record already exists (use sqlCommand to make the query, SqlDataReader go through the data)
            //    if it doesn't exist proceed to adding the record
            //    if it does then tell the user it already exists
            //instert the data into the database    (use sqlCommand to insert data and a function that is part of the sqlCommand called .ExecuteNonQuery())
            //Let the user know it was successful
            //try/catch statement for error handling
            //----------Optional--------//
            //add another form that connects to accounts so you can add a chequing account for the user

            //if (Fname_box.Text == "" || Lname_box.Text == "" || street_no_box.Text == "" || street_name_box.Text == "" || city_box.Text == "" || prov_box.Text == "" || pc_box.Text == "" || phone_box.Text == "" || email_box.Text == "" || dob_box.Text == "") //checks if any of the fields in the form are empty
            //{
            //    MessageBox.Show("Please fill in all fields");
            //}
            //else

            //old code, moved into a function

            bool TextBoxesEmpty = AreTextboxesEmpty();//checking for empty textboxes, prevents duplicated code
            if (TextBoxesEmpty)
            {
                return;
            }
            NewCustomer InsertCustomer = FillFormVariables();//fill variables, return NewCustomer as an object, pass into the RunSQLCommand

            //customer.First_Name = Fname_box.Text.ToUpper();
            //customer.Last_Name = Lname_box.Text.ToUpper();
            //customer.Street_No = street_no_box.Text;
            //customer.Street_Name = street_name_box.Text.ToUpper();
            //customer.City = city_box.Text.ToUpper();
            //customer.Province = prov_box.Text.ToUpper();
            //customer.Postal_Code = pc_box.Text.ToUpper();
            //customer.Phone_No = phone_box.Text;
            //customer.Email = email_box.Text.ToUpper();
            //customer.DOB = dob_box.Value;
            //Customer_ID = Cust_ID_box.Text;

            try //try statement catches any errors that may occur, and moves to the catch statement. Try won't crash the program if an error occurs
            {
                //connObj.Open(); //opens connection to database
                using (SqlCommand command = new SqlCommand($"SELECT * FROM Customers WHERE First_Name = @First_Name AND Last_Name = @Last_Name AND Phone_No = @Phone_No AND Email = @Email;", connObj))
                {
                    command.Parameters.AddWithValue("@First_Name", InsertCustomer.First_Name);
                    command.Parameters.AddWithValue("@Last_Name", InsertCustomer.Last_Name);
                    command.Parameters.AddWithValue("@Phone_No", InsertCustomer.Phone_No);
                    command.Parameters.AddWithValue("@Email", InsertCustomer.Email);
                    //command.Parameters.AddWithValue("@DOB", DOB);
                    //Paramaterized SQL statement that searches the database for an existing customer
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        MessageBox.Show("Customer already exists");
                        reader.Close(); //close here
                        return;
                    }
                    reader.Close();//needed to close the reader here as well or got error
                }
                RunSQLCommand(InsertCustomer, $"INSERT INTO Customers (First_Name, Last_Name, Street_No, Street_Name, City, Province, Postal_Code, Phone_No, Email, DOB) VALUES (@First_Name, @Last_Name, @Street_No, @Street_Name, @City, @Province, @Postal_Code, @Phone_No, @Email, @DOB);");
                //using (SqlCommand command2 = new SqlCommand(connObj))
                //{
                //    command2.Parameters.AddWithValue("@First_Name", InsertCustomer.First_Name);
                //    command2.Parameters.AddWithValue("@Last_Name", InsertCustomer.Last_Name);
                //    command2.Parameters.AddWithValue("@Street_No", InsertCustomer.Street_No);
                //    command2.Parameters.AddWithValue("@Street_Name", InsertCustomer.Street_Name);
                //    command2.Parameters.AddWithValue("@City", InsertCustomer.City);
                //    command2.Parameters.AddWithValue("@Province", InsertCustomer.Province);
                //    command2.Parameters.AddWithValue("@Postal_Code", InsertCustomer.Postal_Code);
                //    command2.Parameters.AddWithValue("@Phone_No", InsertCustomer.Phone_No);
                //    command2.Parameters.AddWithValue("@Email", InsertCustomer.Email);
                //    command2.Parameters.AddWithValue("@DOB", InsertCustomer.DOB);
                //    //parameterized SQL statement that inserts the customer into the database
                //    command2.ExecuteNonQuery();//has to come after the SqlCommand statement
                //}

                //old code, moved into a function

                MessageBox.Show("Customer added successfully");
            }
            catch (SqlException ex) //catch statement catches the error and displays it in a message box
            {
                MessageBox.Show("Failed Insert: " + ex.Message);
            }
        }

        private void update_btn_Click(object sender, EventArgs e)
        {  //-------- this is a requierment ---//
           //You should have a connection to the data base on your form load
           // Using SqlCommand and SqlDataReader do the following

            //make sure all of the textboxes are filled in
            //if not ask them to fill it in
            //Use an sql statement to update the data (use sqlCommand to Update data and a function that is part of the sqlCommand called .ExecuteNonQuery())
            //Let the user know it was successful

            bool TextBoxesEmpty = AreTextboxesEmpty();
            if (TextBoxesEmpty)
            {
                return;
            }
            NewCustomer UpdateCustomer = FillFormVariables();
            try
            {
                //if (Fname_box.Text == "" || Lname_box.Text == "" || street_no_box.Text == "" || street_name_box.Text == "" || city_box.Text == "" || prov_box.Text == "" || pc_box.Text == "" || phone_box.Text == "" || email_box.Text == "" || dob_box.Text == "")
                //{
                //    MessageBox.Show("Please fill in all fields");
                //}
                //else
                //{
                //    customer.First_Name = Fname_box.Text.ToUpper();
                //    customer.Last_Name = Lname_box.Text.ToUpper();
                //    customer.Street_No = street_no_box.Text;
                //    customer.Street_Name = street_name_box.Text.ToUpper();
                //    customer.City = city_box.Text.ToUpper();
                //    customer.Province = prov_box.Text.ToUpper();
                //    customer.Postal_Code = pc_box.Text.ToUpper();
                //    customer.Phone_No = phone_box.Text;
                //    customer.Email = email_box.Text.ToUpper();
                //    customer.DOB = dob_box.Value;
                //    customer.Customer_ID = Cust_ID_box.Text;

                //moved into a function

                DialogResult result = MessageBox.Show("Are you sure you want to update this customer?", "Update Customer", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                //Confirmation box anatomy: DialogResult result = MessageBox.Show ("Confirmation question", messagebox title", MessageBoxButtons.YesNo); if (result == DialogResult.Yes) { //code to execute if user clicks yes }
                {
                    RunSQLCommand(UpdateCustomer, $"UPDATE Customers SET First_Name = @First_Name, Last_Name = @Last_Name, Street_No = @Street_No, Street_Name = @Street_Name, City = @City, Province = @Province, Postal_Code = @Postal_Code, Phone_No = @Phone_No, Email = @Email, DOB = @DOB WHERE Customer_ID = @Customer_ID;");
                    //using (SqlCommand command = new SqlCommand(, connObj))
                    //{
                    //    command.Parameters.AddWithValue("@First_Name", UpdateCustomer.First_Name);
                    //    command.Parameters.AddWithValue("@Last_Name", UpdateCustomer.Last_Name);
                    //    command.Parameters.AddWithValue("@Street_No", UpdateCustomer.Street_No);
                    //    command.Parameters.AddWithValue("@Street_Name", UpdateCustomer.Street_Name);
                    //    command.Parameters.AddWithValue("@City", UpdateCustomer.City);
                    //    command.Parameters.AddWithValue("@Province", UpdateCustomer.Province);
                    //    command.Parameters.AddWithValue("@Postal_Code", UpdateCustomer.Postal_Code);
                    //    command.Parameters.AddWithValue("@Phone_No", UpdateCustomer.Phone_No);
                    //    command.Parameters.AddWithValue("@Email", UpdateCustomer.Email);
                    //    command.Parameters.AddWithValue("@DOB", UpdateCustomer.DOB);
                    //    command.Parameters.AddWithValue("@Customer_ID", UpdateCustomer.Customer_ID);
                    //    command.ExecuteNonQuery();
                    //}

                    MessageBox.Show("Customer updated successfully");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Failed Update: " + ex.Message);
            }
        }

        private void find_ID_btn_Click(object sender, EventArgs e)
        {
            //-------- this is a requirement ---//
            //if the customer ID is empty, let the user know to fill it in and leave the function
            //Search for the record
            //if found add to the textboxes using DataReader
            //if not found let the user know

            if (Cust_ID_box.Text == "")
            {
                MessageBox.Show("Please fill in the Customer ID");
            }
            else
            {
                try
                {
                    string Customer_ID = Cust_ID_box.Text; //takes the customer ID from the text box
                    using (SqlCommand command = new SqlCommand($"SELECT * FROM Customers WHERE Customer_ID = {Customer_ID}", connObj))
                    {
                        //connObj.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            bool customerFound = false; //made a boolean variable to check if the customer was found or not
                            while (reader.Read())
                            { //uses the reader to read the data from the database
                                Fname_box.Text = reader["First_Name"].ToString();
                                Lname_box.Text = reader["Last_Name"].ToString();
                                street_no_box.Text = reader["Street_No"].ToString();
                                street_name_box.Text = reader["Street_Name"].ToString();
                                city_box.Text = reader["City"].ToString();
                                prov_box.Text = reader["Province"].ToString();
                                pc_box.Text = reader["Postal_Code"].ToString();
                                phone_box.Text = reader["Phone_No"].ToString();
                                email_box.Text = reader["Email"].ToString();
                                dob_box.Text = reader["DOB"].ToString();

                                customerFound = true; //if true, the customer was found
                                break; //exit loop
                            }

                            if (customerFound)
                            {
                                // customer found, do nothing
                            }
                            else
                            {
                                MessageBox.Show("Customer not found");
                            }

                            reader.Close();
                        }
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("SQL Error: " + ex.Message);
                }
            }
        }

        private void del_btn_Click(object sender, EventArgs e)
        {//-------- this is a requierment ---//
         // ask the user if they are sure they want to
         //    if they dont want to delete, leave the function
         //    if they do proceed to the next step
         //search for the record
         //if you find it delete it
         //inform the user it had successfuly been deleted
         // clear data form form

            if (Cust_ID_box.Text == "") //if the customer_ID box is empty, displays message
            {
                MessageBox.Show("Please fill in the Customer ID");
                return; //ends the function early if the customer ID is blank. Used instead of else statement
            }
            string Customer_ID = Cust_ID_box.Text;
            try //runs only if the customer ID is not blank
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Delete record", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    using (SqlCommand command = new SqlCommand($"DELETE FROM Customers WHERE Customer_ID = @Customer_ID", connObj))
                    {
                        command.Parameters.AddWithValue("@Customer_ID", Customer_ID);
                        command.ExecuteNonQuery();
                    }

                    ClearForm(); //calls the ClearForm function
                    MessageBox.Show("Record successfully deleted");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("SqlError: " + ex.Message);
            }
        }

        private void ClearForm()
        {
            Fname_box.Text = "";
            Lname_box.Text = "";
            street_no_box.Text = "";
            street_name_box.Text = "";
            city_box.Text = "";
            prov_box.Text = "";
            pc_box.Text = "";
            phone_box.Text = "";
            email_box.Text = "";
            dob_box.Text = "";
            Cust_ID_box.Text = "";
            //sets all textboxes to blank field
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Clear form?", "Clear Form", MessageBoxButtons.YesNo);//message, messagebox title, buttons
            if (result == DialogResult.Yes)
            {
                ClearForm(); //calls the ClearForm function on button click
            }
        }

        private void prev_btn_Click(object sender, EventArgs e)
        {   //search the Database for the first customer that who Has an ID less than the current customer
            //if there is not ID less than the current, let the user know they are at the beginning of the file
            //If you do find the data, Display in the Texboxes

            if (Cust_ID_box.Text == "")
            {
                MessageBox.Show("No customer ID found. Please enter a valid customer ID.");
                return;
            }

            int currentCustomerId = int.Parse(Cust_ID_box.Text);//reads data from the Cust_ID_box, stores it in currentCustomerID variable
            using (SqlCommand cmd = new SqlCommand($"SELECT TOP 1 * FROM Customers WHERE Customer_ID < {currentCustomerId} ORDER BY Customer_ID DESC", connObj))
            //retrieves the first customer with an ID less than the current customer
            //used TOP 1 to only retrieve the first customer that matches the criteria, instead of using * to select all customers
            using (SqlDataReader reader = cmd.ExecuteReader())
                if (reader.Read())
                {
                    Cust_ID_box.Text = reader["Customer_ID"].ToString();
                    Fname_box.Text = reader["First_Name"].ToString();
                    Lname_box.Text = reader["Last_Name"].ToString();
                    street_no_box.Text = reader["Street_No"].ToString();
                    street_name_box.Text = reader["Street_Name"].ToString();
                    city_box.Text = reader["City"].ToString();
                    prov_box.Text = reader["Province"].ToString();
                    pc_box.Text = reader["Postal_Code"].ToString();
                    phone_box.Text = reader["Phone_No"].ToString();
                    email_box.Text = reader["Email"].ToString();
                    dob_box.Text = reader["DOB"].ToString();
                    //this is setting the textboxes to the values of the customer with the ID less than the current customer
                }
                else
                {
                    MessageBox.Show("This is the first record");
                }
            //reader.Close(); //not needed because of using statement
        }

        private void next_btn_Click(object sender, EventArgs e)
        {
            if (Cust_ID_box.Text == "")
            {
                MessageBox.Show("No customer ID found. Please enter a valid customer ID.");
                return;
            }

            int currentCustomerId = int.Parse(Cust_ID_box.Text);
            using (SqlCommand cmd = new SqlCommand($"SELECT TOP 1 * FROM Customers WHERE Customer_ID > {currentCustomerId} ORDER BY Customer_ID ASC", connObj))
            //retrieves the first customer with an ID greater than the current customer
            //used TOP 1 instead of * to only retrieve the first record
            using (SqlDataReader reader = cmd.ExecuteReader())
                if (reader.Read())
                {
                    Cust_ID_box.Text = reader["Customer_ID"].ToString();
                    Fname_box.Text = reader["First_Name"].ToString();
                    Lname_box.Text = reader["Last_Name"].ToString();
                    street_no_box.Text = reader["Street_No"].ToString();
                    street_name_box.Text = reader["Street_Name"].ToString();
                    city_box.Text = reader["City"].ToString();
                    prov_box.Text = reader["Province"].ToString();
                    pc_box.Text = reader["Postal_Code"].ToString();
                    phone_box.Text = reader["Phone_No"].ToString();
                    email_box.Text = reader["Email"].ToString();
                    dob_box.Text = reader["DOB"].ToString();
                    //sets the textboxes to the values of the customer with the ID greater than the current customer
                }
                else
                {
                    MessageBox.Show("This is the last record");
                }
            //reader.Close();
        }

        // In Form1
        private Form2 form2Instance; //Declare a Form2 instance. This will be used to check if Form2 is open or not

        private void OpenForm2() //Method to open Form2
        {
            if (form2Instance == null || form2Instance.IsDisposed) //If Form2 is not open, open it.
                                                                   //The IsDisposed property checks if Form2 is open or not
            {
                form2Instance = new Form2(); //Create a new instance of Form2 if it is not open
            }

            form2Instance.Show(); //Show Form2
            form2Instance.BringToFront(); //Bring Form2 to the front
        }

        private void getAll_btn_Click(object sender, EventArgs e)
        {
            OpenForm2(); //calls the OpenForm2 method
        }
    }
}