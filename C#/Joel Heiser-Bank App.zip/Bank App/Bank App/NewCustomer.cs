﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank_App
{
    public class NewCustomer
    {
        public string Customer_ID { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Street_No { get; set; }
        public string Street_Name { get; set; }
        public string City { get; set; }
        public string Province { get; set; }
        public string Postal_Code { get; set; }
        public string Phone_No { get; set; }
        public string Email { get; set; }
        public DateTime DOB { get; set; }
    }
}