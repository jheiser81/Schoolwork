﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_App
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            SqlConnection connObj = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='G:\My Drive\Schoolwork\VS Repos\C#\Bank App\Bank App\Bank.mdf';Integrated Security=True"); //SQL Server connection string
            connObj.Open(); //Open connection
            SqlCommand command = new SqlCommand("SELECT * from Customers;", connObj); //SQL command to select all from Customers table
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command); //Data adapter to fill data table
            DataTable dataTable = new DataTable(); //Data table to hold data
            dataAdapter.Fill(dataTable); //Fill data table
            dataGridView1.DataSource = dataTable; //Set data grid view to data table
        }
    }
}
