﻿namespace Club.Models
{
    public class ClubInfo
    {
        public int ID { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Rank { get; set; }
        public string? DOB { get; set; }
    }
}