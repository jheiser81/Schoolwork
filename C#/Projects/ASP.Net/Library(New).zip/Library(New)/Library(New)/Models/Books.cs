﻿namespace Library_New_.Models
{
    public class Books
    {
        public int Book_ID { get; set; }
        public string? Title { get; set; }
        public string? Genre { get; set; }
        public string? Publisher { get; set; }
        public string? Pub_Date { get; set; }
        public int Author_ID { get; set; }
        public string? First_Name { get; set; }
        public string? Last_Name { get; set; }
    }
}