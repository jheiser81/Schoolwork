﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.RichTextBox4 = New System.Windows.Forms.RichTextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.RichTextBox5 = New System.Windows.Forms.RichTextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.RichTextBox6 = New System.Windows.Forms.RichTextBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.RichTextBox7 = New System.Windows.Forms.RichTextBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.RichTextBox8 = New System.Windows.Forms.RichTextBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(12, 65)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(411, 306)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(148, 520)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(131, 40)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(12, 392)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(411, 122)
        Me.RichTextBox2.TabIndex = 2
        Me.RichTextBox2.Text = ""
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Location = New System.Drawing.Point(429, 65)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.Size = New System.Drawing.Size(283, 168)
        Me.RichTextBox3.TabIndex = 3
        Me.RichTextBox3.Text = ""
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(504, 239)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(131, 40)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'RichTextBox4
        '
        Me.RichTextBox4.Location = New System.Drawing.Point(787, 65)
        Me.RichTextBox4.Name = "RichTextBox4"
        Me.RichTextBox4.Size = New System.Drawing.Size(425, 306)
        Me.RichTextBox4.TabIndex = 5
        Me.RichTextBox4.Text = ""
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(922, 377)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(131, 40)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'RichTextBox5
        '
        Me.RichTextBox5.Location = New System.Drawing.Point(39, 629)
        Me.RichTextBox5.Name = "RichTextBox5"
        Me.RichTextBox5.Size = New System.Drawing.Size(372, 168)
        Me.RichTextBox5.TabIndex = 7
        Me.RichTextBox5.Text = ""
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(148, 803)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(131, 40)
        Me.Button4.TabIndex = 8
        Me.Button4.Text = "Button4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'RichTextBox6
        '
        Me.RichTextBox6.Location = New System.Drawing.Point(441, 392)
        Me.RichTextBox6.Name = "RichTextBox6"
        Me.RichTextBox6.Size = New System.Drawing.Size(308, 168)
        Me.RichTextBox6.TabIndex = 9
        Me.RichTextBox6.Text = ""
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(526, 566)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(131, 40)
        Me.Button5.TabIndex = 10
        Me.Button5.Text = "Button5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'RichTextBox7
        '
        Me.RichTextBox7.Location = New System.Drawing.Point(454, 629)
        Me.RichTextBox7.Name = "RichTextBox7"
        Me.RichTextBox7.Size = New System.Drawing.Size(203, 188)
        Me.RichTextBox7.TabIndex = 11
        Me.RichTextBox7.Text = ""
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(495, 823)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(131, 40)
        Me.Button6.TabIndex = 12
        Me.Button6.Text = "Button6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(663, 693)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(175, 35)
        Me.TextBox1.TabIndex = 13
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(663, 734)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(175, 35)
        Me.TextBox2.TabIndex = 14
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(663, 775)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(131, 40)
        Me.Button7.TabIndex = 15
        Me.Button7.Text = "Button7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'RichTextBox8
        '
        Me.RichTextBox8.Location = New System.Drawing.Point(822, 460)
        Me.RichTextBox8.Name = "RichTextBox8"
        Me.RichTextBox8.Size = New System.Drawing.Size(203, 127)
        Me.RichTextBox8.TabIndex = 16
        Me.RichTextBox8.Text = ""
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(864, 593)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(131, 40)
        Me.Button8.TabIndex = 17
        Me.Button8.Text = "Button8"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(1031, 499)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(175, 35)
        Me.TextBox3.TabIndex = 18
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 30.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1454, 955)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.RichTextBox8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.RichTextBox7)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.RichTextBox6)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.RichTextBox5)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.RichTextBox4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.RichTextBox3)
        Me.Controls.Add(Me.RichTextBox2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents RichTextBox2 As RichTextBox
    Friend WithEvents RichTextBox3 As RichTextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents RichTextBox4 As RichTextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents RichTextBox5 As RichTextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents RichTextBox6 As RichTextBox
    Friend WithEvents Button5 As Button
    Friend WithEvents RichTextBox7 As RichTextBox
    Friend WithEvents Button6 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Button7 As Button
    Friend WithEvents RichTextBox8 As RichTextBox
    Friend WithEvents Button8 As Button
    Friend WithEvents TextBox3 As TextBox
End Class
