﻿Public Class Form1
    Dim previousStorage As Double = 0
    Dim aritmeticOperator As String = ""
    Dim wasLastButtonPressedOperator As Boolean = False
    Sub Calculate()
        '' This is to do the equal calulation
        Dim result As Double '' result variable
        If aritmeticOperator = "+" Then 'check which operator is being used to calculate, in this case we are using additon
            result = previousStorage + Convert.ToDouble(TextBox1.Text) 'sum the previous values with the current textbox value
            TextBox1.Text = result.ToString() 'print result to textbox1
        ElseIf aritmeticOperator = "-" Then 'this is where we subtract
            result = previousStorage - Convert.ToDouble(TextBox1.Text)
            TextBox1.Text = result.ToString()
        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ''this is button 1 with a number value of 1

        If TextBox1.Text = "0" Or wasLastButtonPressedOperator Then 'this checks if the textbox1 has a default 0
            TextBox1.Text = "1" ' if it is a 0 it needs to be replaced with a 1
            wasLastButtonPressedOperator = False
            TextBox2.Text += " 1"
        Else
            TextBox2.Text += "1"
            TextBox1.Text += "1" 'if it is not a 0 then we want to add another 1 to the textbox
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ''this is button 2 with a number value of 2
        If TextBox1.Text = "0" Or wasLastButtonPressedOperator Then ''check to see if the last button pressed was an operator or button, this will be done on every number
            TextBox1.Text = "2"
            TextBox2.Text += " 2"
            wasLastButtonPressedOperator = False
        Else
            TextBox2.Text += "2"
            TextBox1.Text += "2"
        End If
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        '' This is addition
        TextBox2.Text += " +"
        If aritmeticOperator <> "" Then
            Calculate()
        End If
        wasLastButtonPressedOperator = True
        aritmeticOperator = "+" ''we indicate the operator that was used so when we press the = button we can 
        previousStorage = TextBox1.Text 'Store the number form textbox 1 to use later


    End Sub
    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        '' subtraction 
        TextBox2.Text += " -"
        If aritmeticOperator <> "" Then ''check if the operator has any value, which means if it has been selected, 
            Calculate() ''if it does then calculate the previous value with the current textbox value 
        End If
        wasLastButtonPressedOperator = True 'change the value to the true so the program knows you have clicked a operator button
        previousStorage = TextBox1.Text 'Store the number form textbox 1 to use later
        aritmeticOperator = "-" ''store the type of arithmetic to be done next
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        If Not wasLastButtonPressedOperator Then
            Calculate()
        End If

    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        Dim textLength As Double = TextBox1.TextLength - 1
        Dim textboxText As String = TextBox1.Text
        TextBox1.Text = textboxText.Substring(0, textLength)
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click

    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click

    End Sub

    Private Sub SingleClick(sender As Object, e As EventArgs) Handles Button18.Click, Button19.Click
        MessageBox.Show(sender.text.ToString())
    End Sub
End Class
