
// function myFunction() {
// let button = document.getElementById("#nav-btn");
// document.querySelector(".nav")
// document.addEventListener("click", myFunction);
// }

// const nav = document.querySelector(".nav");
// const menu_btn = document.getElementById("nav-btn");
// console.log(nav)

// menu_btn.addEventListener("click", () => {
//     console.log("it clicked before", nav.style.display);
//     nav.style.display = "flex"
// }

const nav = document.querySelector(".nav")
const menu_btn = document.getElementById("nav-btn");
console.log(nav)
//version 1
menu_btn.addEventListener("click", () => {
    console.log("it clicked before", nav.style.display);
  
    // if (nav.style.display === "flex") {
    //    nav.style.display = "none" 
    // }else {
    //     nav.style.display = "flex";
    // }
  
    //version 2
    if (nav.style.display !== "flex") {
        nav.style.display = "flex";
        return;
    }
    nav.style.animationName = "fade-out";
    setTimeout(() => {
       nav.style.display = "none"; 
       console.log(nav.style.animationName);
    }, 1000);
});

    