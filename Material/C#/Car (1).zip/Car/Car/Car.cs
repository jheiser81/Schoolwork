﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car
{
    internal class Car : Vehicle
    {
        public int NumDoors { get; set; }
        public Car(string make, string model, int year, int numDoors) : base(make, model, year)
        {
            this.NumDoors = numDoors;
        }
        public override string Drive()
        {
            return "Car is driving.";
        }
        public void Brake()
        {
            MessageBox.Show("Car is braking.");
        }
    }
}
